#include	<math.h>

double
tan(x)
double	x;
{
	return sin(x)/cos(x);
}
